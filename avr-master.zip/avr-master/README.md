AVR
===
This AVR repository is a mesh of the header files from avr-libc and the latest from Atmel (sourced from Arduino 1.6.3).

# Installation
Install avr-libc.  For Linux, the files are typically installed to /usr/lib/avr.  Once complete, clone this repo into the install folder.


